using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mapbox.Unity.Map;
using Mapbox.Utils;
using Mapbox.CheapRulerCs;


public class MovePlayer : MonoBehaviour
{
    public AbstractMap Map;
    public Vector2d LatLng;
    private Rigidbody playerRb;
    public float speed;
    
    // Start is called before the first frame update
    void Start()
    {
        //Map.InitializeOnStart = true;
        Debug.Log("initializeOnStart => "+Map.InitializeOnStart);
        Debug.Log("hello from the player at the beginning of the game:)");
        LatLng = Map.WorldToGeoPosition(transform.position);
        Debug.Log("Latitude => "+LatLng.x+" Longitude => "+LatLng.y);
        playerRb = GetComponent<Rigidbody>();
        Map.UseCustomScale(50.0f);
    }

    // Update is called once per frame
    void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");
         playerRb.AddForce(Vector3.forward * verticalInput * speed, ForceMode.Impulse);
         playerRb.AddForce(Vector3.right * horizontalInput * speed, ForceMode.Impulse);
        


        //transform.Translate(Vector3.forward * verticalInput * speed * Time.deltaTime);
        //transform.Translate(Vector3.right * horizontalInput * speed * Time.deltaTime);
        // if(Input.GetKey(KeyCode.W)) {
        //     transform.Translate(Vector3.forward * Time.deltaTime * 15.0f);
        //     LatLng = Map.WorldToGeoPosition(transform.position);
        //     Debug.Log("Latitude => "+LatLng.x+" Longitude => "+LatLng.y);
        // }
        // if(Input.GetKey(KeyCode.A)) {
        //     transform.Translate(Vector3.left * Time.deltaTime * 15.0f);
        // }
        // if(Input.GetKey(KeyCode.S)) {
        //     transform.Translate(Vector3.back * Time.deltaTime * 15.0f);
        // }
        // if(Input.GetKey(KeyCode.D)) {
        //     transform.Translate(Vector3.right * Time.deltaTime * 15.0f);
        // }
    }

    void OnCollisionEnter(Collision collisionInfo)
    {
        //BoxCollider 
        BoxCollider buildingCollider = collisionInfo.gameObject.GetComponent<BoxCollider>();
        Debug.Log("collision happened:)");
        Vector2d latlngTrigger = Map.WorldToGeoPosition(buildingCollider.transform.position);
        Vector2d latlng = Map.WorldToGeoPosition(transform.position);
        Debug.Log("lat => "+ latlngTrigger.x + " long => "+ latlngTrigger.y);
        Debug.Log("Transform component (position) => "+ buildingCollider.transform.position);
        Debug.Log("Transform => "+ buildingCollider.size);
        double[] elephantCastle = new double[] { latlngTrigger.x, latlngTrigger.y };
	    double[] bigBen = new double[] { latlng.x, latlng.y };
	    CheapRuler cr = new CheapRuler(elephantCastle[1], CheapRulerUnits.Kilometers);
	    Debug.Log(cr.Distance(elephantCastle, bigBen));
        Debug.Log(elephantCastle[0]+", "+elephantCastle[1]);
        Debug.Log(bigBen[0]+", "+bigBen[1]);
        

    }
    void OnTriggerEnter(Collider other)
    {
        if(other.tag == "border"){
            Debug.Log("Near the border!!");
        }
    }
    
    
    
}
