using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using SimpleJSON;
using UnityEngine.UI;

public class WeatherInfo : MonoBehaviour
{
    private const string API_URL = "http://api.worldweatheronline.com/premium/v1/marine.ashx";
    private const string API_KEY = "79d1a4caf3ee4e29912134624221206";
    private string LAT;
    private string LON;
    private string URL;
    private string result;
    private string[] result_arr = new string[40];
    public RawImage weatherIconUrl;
    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void HandleRequest(string lat, string lon)
    {
        //http://api.worldweatheronline.com/premium/v1/marine.ashx?key=79d1a4caf3ee4e29912134624221206&q=7,90&format=json&tide=yes&tp=1
        LAT = lat;
        LON = lon;
        URL =  string.Format("{0}?key={1}&q={2},{3}&format=json&tide=yes&tp=1", API_URL, API_KEY, LAT, LON);
        Debug.Log(URL);
        //starting coroutine
        StartCoroutine(ProcessRequest(URL));
    }
    private IEnumerator ProcessRequest(string uri)
    {
        using (UnityWebRequest request = UnityWebRequest.Get(uri))
        {
            //request.SetRequestHeader("appid", API_KEY);
            //request.SetRequestHeader("lat", LAT);
            //request.SetRequestHeader("lon", LON);
            //request.SetRequestHeader("exclude", EXCLUDE);
            
            yield return request.SendWebRequest();

            if(request.result == UnityWebRequest.Result.ConnectionError)
            {
                Debug.Log(request.error);
            }
            else
            {
                //Debug.Log(request.downloadHandler.text);
                JSONNode data = JSON.Parse(request.downloadHandler.text);
                result_arr[0] = data["data"]["weather"][0]["date"];//date
                result_arr[1] = data["data"]["weather"][0]["tides"][0]["tide_data"][0]["tideTime"];
                result_arr[2] = data["data"]["weather"][0]["tides"][0]["tide_data"][0]["tideHeight_mt"];
                result_arr[3] = data["data"]["weather"][0]["tides"][0]["tide_data"][0]["tide_type"];

                result_arr[4] = data["data"]["weather"][0]["tides"][0]["tide_data"][1]["tideTime"];
                result_arr[5] = data["data"]["weather"][0]["tides"][0]["tide_data"][1]["tideHeight_mt"];
                result_arr[6] = data["data"]["weather"][0]["tides"][0]["tide_data"][1]["tide_type"];

                result_arr[7] = data["data"]["weather"][0]["tides"][0]["tide_data"][1]["tideTime"];
                result_arr[8] = data["data"]["weather"][0]["tides"][0]["tide_data"][1]["tideHeight_mt"];
                result_arr[9] = data["data"]["weather"][0]["tides"][0]["tide_data"][1]["tide_type"];

                result_arr[10] = data["data"]["weather"][0]["tides"][0]["tide_data"][2]["tideTime"];
                result_arr[11] = data["data"]["weather"][0]["tides"][0]["tide_data"][2]["tideHeight_mt"];
                result_arr[12] = data["data"]["weather"][0]["tides"][0]["tide_data"][2]["tide_type"];

                result_arr[13] = data["data"]["weather"][0]["hourly"][0]["tempC"];
                result_arr[14] = data["data"]["weather"][0]["hourly"][0]["tempF"];
                result_arr[15] = data["data"]["weather"][0]["hourly"][0]["windspeedMiles"];
                result_arr[16] = data["data"]["weather"][0]["hourly"][0]["windspeedKmph"];
                result_arr[17] = data["data"]["weather"][0]["hourly"][0]["winddirDegree"];
                result_arr[18] = data["data"]["weather"][0]["hourly"][0]["weatherIconUrl"][0]["value"];
                result_arr[19] = data["data"]["weather"][0]["hourly"][0]["weatherDesc"][0]["value"];

                result_arr[20] = data["data"]["weather"][0]["hourly"][0]["humidity"];
                result_arr[21] = data["data"]["weather"][0]["hourly"][0]["visibility"];
                result_arr[22] = data["data"]["weather"][0]["hourly"][0]["visibilityMiles"];
                result_arr[23] = data["data"]["weather"][0]["hourly"][0]["HeatIndexC"];
                result_arr[24] = data["data"]["weather"][0]["hourly"][0]["HeatIndexF"];
                result_arr[25] = data["data"]["weather"][0]["hourly"][0]["DewPointC"];
                result_arr[26] = data["data"]["weather"][0]["hourly"][0]["DewPointF"];
                result_arr[27] = data["data"]["weather"][0]["hourly"][0]["WindChillC"];
                result_arr[28] = data["data"]["weather"][0]["hourly"][0]["WindChillF"];
                result_arr[29] = data["data"]["weather"][0]["hourly"][0]["WindGustMiles"];
                result_arr[30] = data["data"]["weather"][0]["hourly"][0]["WindGustKmph"];
                result_arr[31] = data["data"]["weather"][0]["hourly"][0]["FeelsLikeC"];
                result_arr[32] = data["data"]["weather"][0]["hourly"][0]["FeelsLikeF"];
                result_arr[33] = data["data"]["weather"][0]["hourly"][0]["sigHeight_m"];
                result_arr[34] = data["data"]["weather"][0]["hourly"][0]["swellHeight_m"];
                result_arr[35] = data["data"]["weather"][0]["hourly"][0]["swellDir"];
                result_arr[36] = data["data"]["weather"][0]["hourly"][0]["swellPeriod_secs"];
                result_arr[37] = data["data"]["weather"][0]["hourly"][0]["waterTemp_C"];
                result_arr[38] = data["data"]["weather"][0]["hourly"][0]["waterTemp_F"];
                result_arr[39] = data["data"]["weather"][0]["hourly"][0]["uvIndex"];
                
                
                // result_arr[0] = data["data"]["weather"][0]["date"];
                // result_arr[0] = data["data"]["weather"][0]["date"];
                // result_arr[0] = data["data"]["weather"][0]["date"];
                // result_arr[0] = data["data"]["weather"][0]["date"];
                // foreach(string item in result_arr){
                //     Debug.Log(item);
                // }
                Debug.Log(result_arr);
                StartCoroutine(GetTexture());
                //result = request.downloadHandler.text;
            }
        }
    }
    
    public string getResult()
    {
        return result;
    }
    public void setResult(string result)
    {
        this.result = result;
    }
    public string[] getResultArr()
    {
        return result_arr;
    }
    IEnumerator GetTexture() {
        //Debug.Log(result_arr[18]);
        UnityWebRequest www = UnityWebRequestTexture.GetTexture(result_arr[18]);
        yield return www.SendWebRequest();

        if (www.result != UnityWebRequest.Result.Success) {
            Debug.Log(www.error);
        }
        else {
            weatherIconUrl.texture = DownloadHandlerTexture.GetContent(www);
        }
    }
}