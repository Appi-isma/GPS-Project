using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurnOnMeshCollider : MonoBehaviour
{
    private GameObject[] borders;
    private Rigidbody borderRigidBody;
    // Start is called before the first frame update
    void Start()
    {
        
        borders = GameObject.FindGameObjectsWithTag("border");
        foreach(GameObject border in borders){
            Debug.Log(border);
            MeshCollider borderMesh = border.GetComponent<MeshCollider>();
            //m_Rigidbody.constraints = RigidbodyConstraints.FreezePosition;
            borderRigidBody = border.AddComponent<Rigidbody>();
            borderRigidBody.constraints = RigidbodyConstraints.FreezeAll;
            borderMesh.convex = true;
            borderMesh.isTrigger = true;
        }
        Debug.Log("cubes=>"+ borders);
        Debug.Log("length/coount=>"+borders.Length);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
