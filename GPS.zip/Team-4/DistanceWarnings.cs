using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mapbox.Unity.Map;
using Mapbox.Utils;
using Mapbox.CheapRulerCs;

public class DistanceWarnings : MonoBehaviour
{
    private AbstractMap Map;
    private MeshRenderer meshRenderer;
    // Start is called before the first frame update
    void Start()
    {
        Map = GameObject.Find("Map").GetComponent<AbstractMap>();
        meshRenderer = GetComponent<MeshRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnTriggerEnter(Collider other)
    {
        Vector2d LatLng1;
        Vector2d LatLng2;
        Vector3 collisionPosition;
        if(other.tag == "border"){
            Debug.Log("<color=teal>The trigger message is on...hehehehe</color>");
            Debug.Log(transform.position);
            collisionPosition = new Vector3(transform.position.x+1.5f, transform.position.y, transform.position.z);
            Debug.Log(transform.position.x+1.5);
            LatLng1 = Map.WorldToGeoPosition(transform.position);
            LatLng2 = Map.WorldToGeoPosition(collisionPosition);
            CheapRuler cr = new CheapRuler((double)LatLng1.x, CheapRulerUnits.Meters);
            Debug.Log("the geocoordinates for trigger checking1:"+LatLng1);
            Debug.Log("the geocoordinates for trigger checking2:"+LatLng2);
            double[] a = {LatLng1.y, LatLng1.x};
            double[] b = {LatLng2.y, LatLng2.x};
            double[] c = {LatLng1.x, LatLng1.y};
            double[] d = {LatLng2.x, LatLng2.y};
            Debug.Log(cr.Distance(c, d));
            meshRenderer.enabled = true;
            //Debug.Log(LatLng1.x.GetType());
        }
        //Debug.Log("It's colliding on other things...");
    }
    /// <summary>
    /// OnTriggerExit is called when the Collider other has stopped touching the trigger.
    /// </summary>
    /// <param name="other">The other Collider involved in this collision.</param>
    void OnTriggerExit(Collider other)
    {
        meshRenderer.enabled = false;
    }
}
