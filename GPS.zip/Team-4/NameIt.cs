using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mapbox.Unity.Map;
using Mapbox.Utils;
using UnityEngine.Networking;
using SimpleJSON;
using TMPro;

public class NameIt : MonoBehaviour
{
    
    private AbstractMap Map;
    private Vector2d LatLng;
    private const string API_URL = "https://api.bigdatacloud.net/data/reverse-geocode-client";
    private string lat;
    private string lng;
    private string lang = "en";
    private string URL;
    private string result;
    private GameManager gameManager;


    // Start is called before the first frame update
    void Start()
    {
        Map = GameObject.Find("Map").GetComponent<AbstractMap>();
        LatLng = Map.WorldToGeoPosition(transform.position);
        gameManager = GameObject.Find("GameManager").GetComponent<GameManager>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void GenerateRequest()
    {
        
    }

    private IEnumerator ProcessRequest(string URL)
    {
        using(UnityWebRequest request = UnityWebRequest.Get(URL))
        {
            yield return request.SendWebRequest();

            if(request.result == UnityWebRequest.Result.ConnectionError)
            {
                Debug.Log(request.error);
            }
            else
            {
                //Debug.Log(request.downloadHandler.text);
                JSONNode data = JSON.Parse(request.downloadHandler.text);
                Debug.Log(data["locality"]);
                this.setResult("<b>Fishing Landing Center<b>\n"+"Latitude:"+LatLng.x+"\nLongitude"+LatLng.y+"\nlocality:"+data["locality"]);
                gameManager.SetLandingAreaText(result);
                //LandingCenterText.SetText(data["locality"]);
                //LandingCenterText.text = data["locality"];
            }
        }
    }
    
    private void OnMouseDown()
    {
        //Debug.Log("mouse is clicked!");
        //"https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=37.42159&longitude=-122.0837&localityLanguage=en"
        //Debug.Log("Latitude=> "+LatLng.x+" Longitude=> "+LatLng.y);
        lat = LatLng.x.ToString();
        lng = LatLng.y.ToString();
        Debug.Log(lat+" "+lng);
        URL = string.Format("{0}?latitude={1}&longitude={2}&localityLanguage={3}", API_URL, lat, lng, lang);
        StartCoroutine(ProcessRequest(URL));

    }
    public string getResult(){
        return result;
    }
    public void setResult(string result){
        this.result = result;
    }
    
}
