using System.Collections;
using System.Collections.Generic;
using Mapbox.Unity.Map;
using Mapbox.Utils;
using TMPro;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public GameObject VCam1;

    private AbstractMap Map;

    //private NameIt nameIt;
    public GameObject LandingCenterPanel;

    private GameObject player;

    private Vector2d latlng;

    private WeatherInfo weatherInfo;

    private TextMeshProUGUI weatherInfoText;

    public GameObject weatherInfoUI;

    public GameObject BorderPanel;

    public bool isSafeFromTheBorder = true;

    // Start is called before the first frame update
    void Start()
    {
        //NameIt = GameObject.Find("CoitTower").GetComponent<NameIt>();
        //LandingCenterText = GameObject.Find("LandingCenterText").GetComponent<TextMeshProUGUI>();
        Map = GameObject.Find("Map").GetComponent<AbstractMap>();
        player = GameObject.Find("Player");
        weatherInfo =
            GameObject.Find("WeatherInfo").GetComponent<WeatherInfo>();
        isSafeFromTheBorder = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (isSafeFromTheBorder)
        {
            BorderPanel.gameObject.SetActive(false);
        }
        else
        {
            BorderPanel.gameObject.SetActive(true);
        }
    }

    public void ChangeCameraView()
    {
        //Debug.Log(VCam1);
        if (VCam1.activeSelf)
        {
            //Debug.Log("hurrah, the gameObject is active....");
            VCam1.gameObject.SetActive(false);
        }
        else
        {
            VCam1.gameObject.SetActive(true);
        }
    }

    public void SetLandingAreaText(string result)
    {
        LandingCenterPanel.SetActive(true);
        TextMeshProUGUI LandingCenterText =
            GameObject
                .Find("LandingCenterText")
                .GetComponent<TextMeshProUGUI>();

        //RectTransform LandingCenterPanel_rt = GameObject.Find("LandingCenterText").GetComponent<RectTransform>();
        //LeanTween.moveZ(LandingCenterPanel_rt, -100f, 10f);
        LandingCenterText.text = result;
    }

    public void SetWeatherData()
    {
        if (!weatherInfoUI.activeSelf)
        {
            latlng = Map.WorldToGeoPosition(player.transform.position);
            weatherInfo.HandleRequest(latlng.x.ToString(), latlng.y.ToString());

            //weatherInfo.getResult();
            weatherInfoUI.SetActive(true);
            weatherInfoText =
                GameObject.Find("OtherWeatherData").GetComponent<TextMeshProUGUI>();
            string otherWeatherDataValue =
                "tempC = " +
                weatherInfo.getResultArr()[13] +
                "\t\ttempF = " +
                weatherInfo.getResultArr()[14] +
                "\nwindspeedMiles = " + 
                weatherInfo.getResultArr()[15] +
                "\twindspeedKmph = " +
                weatherInfo.getResultArr()[16] +
                "\nwinddirDegree = " + 
                weatherInfo.getResultArr()[17] +
                "\tdate = " +
                weatherInfo.getResultArr()[0] +
                "\nhumidity = " +
                weatherInfo.getResultArr()[20] +
                "\t\tuvIndex = " +
                weatherInfo.getResultArr()[39] +
                "\nvisibility = " +
                weatherInfo.getResultArr()[21] +
                "\t\tvisibilityMiles = " +
                weatherInfo.getResultArr()[22] +
                "\nHeatIndexC = " +
                weatherInfo.getResultArr()[23] +
                "\tHeatIndexF = " +
                weatherInfo.getResultArr()[24] +
                "\nDewPointC = " +
                weatherInfo.getResultArr()[25] +
                "\tDewPointF = " +
                weatherInfo.getResultArr()[26] +
                "\nWindChillC = " +
                weatherInfo.getResultArr()[27] +
                "\tWindChillF = " +
                weatherInfo.getResultArr()[28] +
                "\nWindGustMiles = "+
                weatherInfo.getResultArr()[29] +
                "\tWindGustKmph = "+
                weatherInfo.getResultArr()[30] +
                "\nFeelsLikeC = " +
                weatherInfo.getResultArr()[31]+
                "\tFeelsLikeF = " +
                weatherInfo.getResultArr()[32]+
                "\nsigHeight_m = "+
                weatherInfo.getResultArr()[33]+
                "\tswellHeight_m = "+
                weatherInfo.getResultArr()[34]+
                "\nswellDir = "+
                weatherInfo.getResultArr()[35]+
                "\t\tswellPeriod = "+
                weatherInfo.getResultArr()[36]+
                "\nwaterTemp_C = "+
                weatherInfo.getResultArr()[37]+
                "\twaterTemp_F = "+
                weatherInfo.getResultArr()[38] + 
                "\nweatherDesc = " + 
                weatherInfo.getResultArr()[19];
            //string value = 
            weatherInfoText.text = otherWeatherDataValue;
        }
        else
        {
            weatherInfoUI.SetActive(false);
        }
    }
}
